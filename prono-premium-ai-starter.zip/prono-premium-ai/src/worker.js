const API_BASE = "https://v3.football.api-sports.io";

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (url.pathname === "/api/fixtures") {
      return getFixtures(request, env, ctx);
    }

    return env.ASSETS.fetch(request);
  },
};

async function getFixtures(request, env, ctx) {
  if (request.method !== "GET") {
    return json({ error: "Méthode non autorisée." }, 405);
  }

  if (!env.API_FOOTBALL_KEY) {
    return json({
      error: "La clé API n'est pas encore configurée sur le serveur.",
      setup: "Ajoutez API_FOOTBALL_KEY dans les secrets Cloudflare."
    }, 503);
  }

  const incoming = new URL(request.url);
  const date = incoming.searchParams.get("date") || new Date().toISOString().slice(0, 10);

  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return json({ error: "Date invalide. Format attendu : AAAA-MM-JJ." }, 400);
  }

  // Cache partagé pendant 15 minutes afin de protéger le quota API.
  const cache = caches.default;
  const cacheUrl = new URL(`/api/fixtures?date=${date}`, incoming.origin);
  const cacheKey = new Request(cacheUrl.toString(), { method: "GET" });
  const cached = await cache.match(cacheKey);
  if (cached) return cached;

  const apiUrl = new URL(`${API_BASE}/fixtures`);
  apiUrl.searchParams.set("date", date);
  apiUrl.searchParams.set("timezone", "Africa/Abidjan");

  let upstream;
  try {
    upstream = await fetch(apiUrl.toString(), {
      headers: { "x-apisports-key": env.API_FOOTBALL_KEY }
    });
  } catch {
    return json({ error: "Impossible de joindre le fournisseur de données football." }, 502);
  }

  const payload = await upstream.json().catch(() => null);
  if (!upstream.ok || !payload) {
    return json({
      error: "Le fournisseur API-Football a renvoyé une erreur.",
      status: upstream.status
    }, 502);
  }

  if (payload.errors && Object.keys(payload.errors).length > 0) {
    return json({ error: "Erreur API-Football.", details: payload.errors }, 502);
  }

  const fixtures = (payload.response || []).map((item) => ({
    id: item.fixture?.id,
    date: item.fixture?.date,
    status: item.fixture?.status?.short,
    elapsed: item.fixture?.status?.elapsed,
    league: item.league?.name,
    country: item.league?.country,
    home: item.teams?.home?.name,
    away: item.teams?.away?.name,
    homeLogo: item.teams?.home?.logo,
    awayLogo: item.teams?.away?.logo,
    homeGoals: item.goals?.home,
    awayGoals: item.goals?.away
  }));

  const response = json({
    date,
    count: fixtures.length,
    fixtures,
    note: "Les matchs proviennent d'API-Football. Les prédictions IA ne sont pas encore activées."
  }, 200, {
    "Cache-Control": "public, max-age=0, s-maxage=900"
  });

  ctx.waitUntil(cache.put(cacheKey, response.clone()));
  return response;
}

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      ...extraHeaders
    }
  });
}
