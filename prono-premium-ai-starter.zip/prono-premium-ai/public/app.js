const dateInput = document.querySelector("#match-date");
const matchesEl = document.querySelector("#matches");
const messageEl = document.querySelector("#message");
const countEl = document.querySelector("#match-count");
const stateEl = document.querySelector("#data-state");
const updatedEl = document.querySelector("#updated-at");

function localDate() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Africa/Abidjan", year: "numeric", month: "2-digit", day: "2-digit"
  }).formatToParts(new Date());
  const p = Object.fromEntries(parts.map(x => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}`;
}
dateInput.value = localDate();
document.querySelector("#year").textContent = new Date().getFullYear();

function safe(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  }[ch]));
}

function formatTime(value) {
  if (!value) return "Heure à confirmer";
  return new Intl.DateTimeFormat("fr-FR", {
    timeZone: "Africa/Abidjan", hour: "2-digit", minute: "2-digit"
  }).format(new Date(value));
}

async function loadMatches() {
  matchesEl.innerHTML = "";
  messageEl.textContent = "Chargement des matchs…";
  stateEl.textContent = "Chargement";
  countEl.textContent = "—";

  try {
    const response = await fetch(`/api/fixtures?date=${encodeURIComponent(dateInput.value)}`);
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Erreur de chargement.");
    const fixtures = data.fixtures || [];
    countEl.textContent = data.count ?? fixtures.length;
    stateEl.textContent = "Connecté";
    updatedEl.textContent = `Mis à jour à ${new Date().toLocaleTimeString("fr-FR")}`;

    if (!fixtures.length) {
      messageEl.textContent = "Aucun match retourné pour cette date. Essaie une autre date.";
      return;
    }
    messageEl.textContent = data.note || "Matchs chargés.";
    matchesEl.innerHTML = fixtures.map(f => `
      <article class="match">
        <div class="league">${safe(f.league)} · ${safe(f.country)}</div>
        <div class="teams">
          <div class="team">${safe(f.home)}</div>
          <div class="vs">${f.homeGoals !== null && f.awayGoals !== null ? `${safe(f.homeGoals)} - ${safe(f.awayGoals)}` : "VS"}</div>
          <div class="team">${safe(f.away)}</div>
        </div>
        <div class="meta">
          <span>${formatTime(f.date)} · ${safe(f.status || "—")}</span>
          <span>Match #${safe(f.id)}</span>
        </div>
      </article>
    `).join("");
  } catch (error) {
    stateEl.textContent = "À vérifier";
    messageEl.textContent = `${error.message} Vérifie le secret API_FOOTBALL_KEY dans Cloudflare.`;
  }
}

document.querySelector("#refresh").addEventListener("click", loadMatches);
dateInput.addEventListener("change", loadMatches);
loadMatches();
